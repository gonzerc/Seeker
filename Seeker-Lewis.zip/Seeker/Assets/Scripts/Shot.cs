﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.AI;

public class Shot : MonoBehaviour {

    public float bulletSpeed;
    Rigidbody rb;
    public GameObject gb;
    public GameObject mainCam;
    public GameObject quarryCam;

	// Use this for initialization
	void Start ()
    {
        rb = GetComponent<Rigidbody>();
        gb = GetComponent<GameObject>();
        rb.velocity = transform.forward * bulletSpeed;

        quarryCam.gameObject.SetActive(false);  //Quarry Cam is set false until the mission fails
    }

    /*private void OnCollisionEnter(Collision collision)
    {
        Collider c = collision.collider;

        c.GetComponent<Rigidbody>().useGravity = false;
        c.GetComponent<NavMeshAgent>().enabled = false;
    }*/

    void OnCollisionEnter(Collision col)
    {
        if (col.gameObject.tag == "FakeTarget")
        {
            Debug.Log("WRONG TARGET");
            col.gameObject.SetActive(false);
            Destroy(gb.gameObject);
            quarryCam.gameObject.SetActive(true);  //Quarry Cam is set true when nontarget is killed
        }

        if (col.gameObject.tag == "Target")
        {
            Debug.Log("QUARRY HIT");
            col.gameObject.SetActive(false);
            Destroy(gb.gameObject);

        }
    }
}
